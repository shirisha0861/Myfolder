/*
 * package com.example.demo.Entity;
 * 
 * import javax.persistence.*;
 * 
 * @Entity
 * 
 * public class Cart_item {
 * 
 * @Id
 * 
 * @GeneratedValue(strategy = GenerationType.IDENTITY) Long cart_id;
 * 
 * @ManyToOne public Product product; double subtotal; String name;
 * 
 * public Cart_item(){
 * 
 * }
 * 
 * public Long getCart_id() { return cart_id; }
 * 
 * public void setCart_id(Long cart_id) { this.cart_id = cart_id; }
 * 
 * public Product getProduct() { return product; }
 * 
 * public static void setProduct(Product product) { this.product = product; }
 * 
 * public double getSubtotal() { return subtotal; }
 * 
 * public static void setSubtotal(double subtotal) { this.subtotal = subtotal; }
 * 
 * public String getName() { return name; }
 * 
 * public static void setName(String name) { this.name = name; } }
 */
