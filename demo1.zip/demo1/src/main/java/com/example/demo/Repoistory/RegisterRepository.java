package com.example.demo.Repoistory;

import com.example.demo.Entity.Register;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.core.CrudMethods;

public interface RegisterRepository extends CrudRepository<Register, Integer> {

}
